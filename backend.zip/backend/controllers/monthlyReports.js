import zbcDB from "../config/zbcDB.js";
import adminDB from "../config/adminDB.js";


// GET COMPOUND POLYMER-WISE MONTHLY REPORT
export const getCompoundPolymerMonthlyReport = async (req, res) => {
  try {
    const { financial_year } = req.query;

    if (!financial_year) {
      return res.status(400).json({
        success: false,
        message: "Financial year is required",
      });
    }

    const [rows] = await zbcDB.query(`
      SELECT polymer_name,month,SUM(qty) AS total_qty,SUM(qty * rate) AS total_cost
      FROM compound_monthly_report
      WHERE financial_year = ?
        AND polymer_name IS NOT NULL
        AND TRIM(polymer_name) <> ''
      GROUP BY polymer_name, month
      ORDER BY polymer_name, month`,
      [financial_year]
    );

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error(
      "Error fetching compound polymer monthly report:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to fetch compound polymer monthly report",
      error: error.message,
    });
  }
};
// GET CUSTOMER WISE MONTHLY REPORT
export const getCustomerWiseMonthlyReport = async (req, res) => {
  try {
    const financialYear = String(req.query.financialYear || "").trim();
    const month = Number(req.query.month);

    if (!financialYear || !Number.isInteger(month) || month < 1 || month > 12) {
      return res.status(400).json({
        success: false,
        message: "financialYear and a valid month (1-12) are required.",
      });
    }

    // Monthly amounts/rates come from molding_monthly_report.
    const [rows] = await zbcDB.query(`
            SELECT
            m.id AS molding_id,
            m.transaction_id,
            m.status,
            m.customer_name AS customer_id,
            m.production_unit AS production_unit_id,
            m.billing_unit AS billing_unit_id,
            m.sub_department AS sub_department_id,
            m.sub_category AS sub_category_id,
            m.part_no,
            m.part_name,
            m.fg_code,
            mm.financial_year,
            mm.month,
            mm.month_name,
            mm.subtotal_a,
            mm.part_cost,
            mm.customer_sales_cost,
            mm.monthly_quantity
            FROM molding_table m
            INNER JOIN molding_monthly_report mm
            ON mm.molding_id = m.id
            AND mm.transaction_id = m.transaction_id
            WHERE mm.financial_year = ?
            AND mm.month = ?
            ORDER BY m.customer_name, m.sub_category, m.part_no`,
      [financialYear, month]
    );
    if (!rows.length) {
      return res.json({ success: true, data: [] });
    }
    const uniqueIds = (field) =>
      [...new Set(rows.map((row) => row[field]).filter((value) => value !== null && value !== undefined && value !== ""))];
    const customerIds = uniqueIds("customer_id");
    const productionUnitIds = uniqueIds("production_unit_id");
    const billingUnitIds = uniqueIds("billing_unit_id");
    const subDepartmentIds = uniqueIds("sub_department_id");
    const subCategoryIds = uniqueIds("sub_category_id");
    const [
      [customers],
      [productionUnits],
      [billingUnits],
      [subDepartments],
      [subCategories],
    ] = await Promise.all([
      customerIds.length
        ? adminDB.query("SELECT id, customer_name AS label FROM customer_master WHERE id IN (?)", [customerIds])
        : Promise.resolve([[]]),
      productionUnitIds.length
        ? adminDB.query("SELECT id, unit AS label FROM unit_master WHERE id IN (?)", [productionUnitIds])
        : Promise.resolve([[]]),
      billingUnitIds.length
        ? adminDB.query("SELECT id, unit AS label FROM unit_master WHERE id IN (?)", [billingUnitIds])
        : Promise.resolve([[]]),
      subDepartmentIds.length
        ? adminDB.query("SELECT id, sub_department_name AS label FROM sub_department_master WHERE id IN (?)", [subDepartmentIds])
        : Promise.resolve([[]]),
      subCategoryIds.length
        ? adminDB.query("SELECT id, sub_category_name AS label FROM sub_category_master WHERE id IN (?)", [subCategoryIds])
        : Promise.resolve([[]]),
    ]);

    const makeMap = (items) => new Map(items.map((item) => [String(item.id), item.label]));
    const customerMap = makeMap(customers);
    const productionUnitMap = makeMap(productionUnits);
    const billingUnitMap = makeMap(billingUnits);
    const subDepartmentMap = makeMap(subDepartments);
    const subCategoryMap = makeMap(subCategories);
    const resolveLabel = (map, value) => map.get(String(value)) || String(value ?? "");
    return res.json({
      success: true,
      data: rows.map((row) => ({
        molding_id: row.molding_id,
        transaction_id: row.transaction_id,
        status: row.status,
        financial_year: row.financial_year,
        month: Number(row.month),
        month_name: row.month_name,
        customer_name: resolveLabel(customerMap, row.customer_id),
        customer_id: row.customer_id,
        production_unit: resolveLabel(productionUnitMap, row.production_unit_id),
        production_unit_id: row.production_unit_id,
        billing_unit: resolveLabel(billingUnitMap, row.billing_unit_id),
        billing_unit_id: row.billing_unit_id,
        sub_department: resolveLabel(subDepartmentMap, row.sub_department_id),
        sub_category: resolveLabel(subCategoryMap, row.sub_category_id),
        sub_category_id: row.sub_category_id,
        part_no: row.part_no || "",
        part_name: row.part_name || "",
        fg_code: row.fg_code || "",
        subtotal_a: row.subtotal_a === null ? null : Number(row.subtotal_a),
        part_cost: row.part_cost === null ? null : Number(row.part_cost),
        customer_sales_cost: row.customer_sales_cost === null ? null : Number(row.customer_sales_cost),
        monthly_quantity: row.monthly_quantity === null ? 0 : Number(row.monthly_quantity),
      })),
    });
  } catch (error) {
    console.error("Customer wise monthly report error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to load Customer Wise Monthly Report.",
      error: error.message,
    });
  }
};