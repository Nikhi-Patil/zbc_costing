import zbcDB from "../config/zbcDB.js";
import adminDB from "../config/adminDB.js";

/* GET SALES MONTHLY REPORT */
export const getSalesMonthlyReport = async (req, res) => {
    try {
        const { financialYear, financial_year, partNo } = req.query;
        const selectedFinancialYear =
            financialYear || financial_year;
        if (!selectedFinancialYear) {
            return res.status(400).json({
                success: false,
                message: "Financial Year is required",
            });
        }

        let sql = `
            SELECT
                id,
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate
            FROM sales_monthly
            WHERE financial_year = ? `;
        const params = [
            String(selectedFinancialYear).trim(),
        ];

        if (partNo && String(partNo).trim()) {
            sql += `AND LOWER(TRIM(part_no))
                    LIKE LOWER(TRIM(?))`;
            params.push(`%${String(partNo).trim()}%`);
        }

        sql += ` ORDER BY
                part_no ASC,
                month ASC `;

        const [rows] = await zbcDB.query(sql, params);
        return res.json({ success: true, data: rows, });
    } catch (error) {
        console.error("Error fetching Sales Monthly Report:", error);
        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch Sales Monthly Report",
            error: error.message,
        });
    }
};

/* GET PREVIOUS MONTH SALES FOR COSTING */
export const getPreviousMonthSales = async (req, res) => {
    try {
        const {
            partNo,
            financialYear,
            month,
        } = req.query;

        if (!partNo || !financialYear || !month) {
            return res.status(400).json({
                success: false,
                message: "Part No, Financial Year and Month are required",
            });
        }

        const currentMonth = Number(month);

        if (
            !Number.isInteger(currentMonth) ||
            currentMonth < 1 ||
            currentMonth > 12
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid Month",
            });
        }

        /*
         * Example:
         *
         * April 2026  -> March 2026
         * January 2027 -> December 2026
         */

        let previousMonth;
        let previousFinancialYear;

        if (currentMonth === 1) {
            // January -> December of previous FY
            previousMonth = 12;

            const startYear = Number(
                String(financialYear).split("-")[0]
            );

            previousFinancialYear = `${startYear - 1}-${String(startYear - 1 + 1).slice(-2)}`;
        } else {
            previousMonth = currentMonth - 1;

            /*
             * If current month is April,
             * previous month is March of previous FY.
             */
            if (currentMonth === 4) {
                const startYear = Number(
                    String(financialYear).split("-")[0]
                );

                previousFinancialYear = `${startYear - 1}-${String(startYear).slice(-2)}`;
            } else {
                previousFinancialYear = String(financialYear).trim();
            }
        }

        /*
         * If multiple records exist for the same Part/FY/Month,
         * take the record having the maximum Qty.
         */
        const [rows] = await zbcDB.query(
            `
            SELECT
                id,
                part_no,
                part_name,
                financial_year,
                month,
                qty,
                sell_rate
            FROM sales_monthly
            WHERE LOWER(TRIM(part_no)) = LOWER(TRIM(?))
              AND financial_year = ?
              AND month = ?
            ORDER BY qty ASC, id ASC
            LIMIT 1
            `,
            [
                String(partNo).trim(),
                previousFinancialYear,
                previousMonth,
            ]
        );

        if (rows.length === 0) {
            return res.json({
                success: true,
                found: false,
                data: null,
                previousFinancialYear,
                previousMonth,
            });
        }

        return res.json({
            success: true,
            found: true,
            previousFinancialYear,
            previousMonth,
            data: {
                qty: rows[0].qty,
                sell_rate: rows[0].sell_rate,
            },
        });

    } catch (error) {
        console.error(
            "Previous Month Sales error:",
            error
        );

        return res.status(500).json({
            success: false,
            message: "Failed to fetch previous month sales",
            error: error.message,
        });
    }
};

/* GET ONE SALES MONTHLY RECORD */
export const getSalesMonthlyById = async (req, res) => {
    try {
        const { id } = req.params;
        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Record ID is required",
            });
        }

        const [rows] = await zbcDB.query(`
            SELECT
                id,
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate,
                created_at,
                updated_at
            FROM sales_monthly
            WHERE id = ?
            LIMIT 1`,
            [id]
        );
        if (rows.length === 0) {
            return res.status(404).json({
                success: false,
                message:
                    "Sales Monthly record not found",
            });
        }
        return res.json({ success: true, data: rows[0], });
    } catch (error) {
        console.error("Error fetching Sales Monthly record:", error);
        return res.status(500).json({
            success: false,
            message:
                "Failed to fetch Sales Monthly record",
            error: error.message,
        });
    }
};

/* CHECK EXISTING RECORD */
export const checkSalesMonthly = async (req, res) => {
    try {
        const {
            partNo,
            part_no,
            month,
            financialYear,
            financial_year,
        } = req.query;
        const selectedPartNo = partNo || part_no;
        const selectedFinancialYear = financialYear || financial_year;
        if (
            !selectedPartNo ||
            !month ||
            !selectedFinancialYear
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Part No, Month and Financial Year are required",
            });
        }
        const monthNumber = Number(month);
        if (
            !Number.isInteger(monthNumber) ||
            monthNumber < 1 ||
            monthNumber > 12
        ) {
            return res.status(400).json({
                success: false,
                message: "Invalid Month",
            });
        }
        const [rows] = await zbcDB.query(`
            SELECT
                id,
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate,
                created_at,
                updated_at
            FROM sales_monthly
            WHERE LOWER(TRIM(part_no))
                    = LOWER(TRIM(?))
                AND financial_year = ?
                AND month = ?
            LIMIT 1`,
            [
                String(selectedPartNo).trim(),
                String(selectedFinancialYear).trim(),
                monthNumber,
            ]
        );
        if (rows.length === 0) {
            return res.json({
                success: true,
                found: false,
                data: null,
            });
        }
        return res.json({
            success: true,
            found: true,
            data: rows[0],
        });
    } catch (error) {
        console.error("Check Sales Monthly error:", error);
        return res.status(500).json({
            success: false,
            message:
                "Failed to check Sales Monthly record",
            error: error.message,
        });
    }
};

/* CREATE SALES MONTHLY */
export const createSalesMonthly = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const {
            partNo,
            partName,
            unit,
            financialYear,
            month,
            qty,
            sellRate,
        } = req.body;

        /* BASIC VALIDATION */
        if (!partNo || !String(partNo).trim()) {
            return res.status(400).json({ success: false, message: "Part No. is required", });
        }
        if (!unit || !String(unit).trim()) {
            return res.status(400).json({ success: false, message: "Unit is required", });
        }
        if (!financialYear || !String(financialYear).trim()) {
            return res.status(400).json({ success: false, message: "Financial Year is required", });
        }
        const monthNumber = Number(month);
        if (!Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) {
            return res.status(400).json({ success: false, message: "Month must be between 1 and 12", });
        }

        /* QTY */
        let finalQty = null;
        if (qty !== undefined && qty !== null && qty !== "") {
            finalQty = Number(qty);
            if (!Number.isFinite(finalQty) || finalQty < 0) {
                return res.status(400).json({
                    success: false,
                    message: "Qty must be a valid non-negative number",
                });
            }
        }

        /* SELL RATE */
        let finalSellRate = null;
        if (sellRate !== undefined && sellRate !== null && sellRate !== "") {
            finalSellRate = Number(sellRate);
            if (!Number.isFinite(finalSellRate) || finalSellRate < 0) {
                return res.status(400).json({
                    success: false,
                    message: "Sell Rate must be a valid non-negative number",
                });
            }
        }
        if (finalQty === null && finalSellRate === null) {
            return res.status(400).json({
                success: false,
                message: "Enter Qty or Sell Rate",
            });
        }


        /* FIND PART FROM PART MASTER */
        const [partRows] = await adminDB.query(`
            SELECT id,part_no,part_name
            FROM part_master
            WHERE LOWER(TRIM(part_no))
                    = LOWER(TRIM(?))
            LIMIT 1`,
            [String(partNo).trim(),]
        );
        if (partRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: `Part No. '${partNo}' was not found in Part Master`,
            });
        }
        const part = partRows[0];

        /* FIND UNIT FROM UNIT MASTER */
        const [unitRows] = await adminDB.query(`
            SELECT id,unit
            FROM unit_master
            WHERE LOWER(TRIM(unit))
                    = LOWER(TRIM(?))
            LIMIT 1`,
            [String(unit).trim(),]
        );
        if (unitRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: `Unit '${unit}' was not found in Unit Master`,
            });
        }
        const unitMaster = unitRows[0];

        /* INSERT / UPDATE */
        const [result] = await zbcDB.query(`
            INSERT INTO sales_monthly (
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate,
                created_by,
                updated_by
                )VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                part.id,
                part.part_no,
                partName || part.part_name || null,
                unitMaster.id,
                unitMaster.unit,
                String(financialYear).trim(),
                monthNumber,
                finalQty,
                finalSellRate,
                userName,
                userName,
            ]
        );

        /* GET SAVED RECORD */
        const [savedRows] = await zbcDB.query(`
            SELECT
                id,
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate,
                created_at,
                updated_at
            FROM sales_monthly
            WHERE part_id = ?
                AND financial_year = ?
                AND month = ?
            LIMIT 1`,
            [part.id, String(financialYear).trim(), monthNumber,]
        );
        return res.status(201).json({
            success: true,
            message: "Sales Monthly entry saved successfully",
            id: savedRows[0]?.id ||
                result.insertId ||
                null,
            data: savedRows[0] || null,
        });
    } catch (error) {
        console.error("Error saving Sales Monthly entry:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to save Sales Monthly entry",
            error: error.message,
            code: error.code,
            sqlState: error.sqlState,
        });
    }
};

/* BULK CREATE / UPDATE SALES MONTHLY */
export const bulkCreateSalesMonthly = async (req, res) => {
    let connection;

    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const { financialYear, entries } = req.body;

        /* -------------------------------------------------
           BASIC VALIDATION
        ------------------------------------------------- */

        if (!Array.isArray(entries) || entries.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No bulk entries received",
            });
        }

        if (entries.length > 5000) {
            return res.status(400).json({
                success: false,
                message: "Maximum 5000 records can be uploaded at once.",
            });
        }

        /*
         * financialYear is now optional at request level.
         *
         * Each Excel row should contain:
         * entry.financialYear
         *
         * If the frontend still sends a general financialYear,
         * it will be used as fallback when a row does not contain FY.
         */
        const fallbackFinancialYear =
            financialYear && String(financialYear).trim()
                ? String(financialYear).trim()
                : null;

        /* -------------------------------------------------
           LOAD PART MASTER ONCE
        ------------------------------------------------- */

        const [partRows] = await adminDB.query(`
            SELECT
                id,
                part_no,
                part_name
            FROM part_master
        `);

        const partMap = new Map();

        partRows.forEach((part) => {
            partMap.set(
                String(part.part_no)
                    .trim()
                    .toLowerCase(),
                part
            );
        });

        /* -------------------------------------------------
           LOAD UNIT MASTER ONCE
        ------------------------------------------------- */

        const [unitRows] = await adminDB.query(`
            SELECT
                id,
                unit
            FROM unit_master
        `);

        const unitMap = new Map();

        unitRows.forEach((unit) => {
            unitMap.set(
                String(unit.unit)
                    .trim()
                    .toLowerCase(),
                unit
            );
        });

        /* -------------------------------------------------
           VALIDATE ENTRIES
        ------------------------------------------------- */

        const validatedEntries = [];
        const errors = [];

        /*
         * Duplicate detection inside uploaded Excel.
         *
         * Database identity:
         *
         * part_id
         * unit_id
         * month
         * financial_year
         *
         * Therefore the same Part + Unit + Month can exist
         * in different Financial Years.
         */

        const duplicateMap = new Map();

        entries.forEach((entry, index) => {
            const excelRow =
                Number(entry.excelRow) || index + 2;

            const partNo = String(
                entry.partNo ??
                entry.part_no ??
                ""
            ).trim();

            const partName = String(
                entry.partName ??
                entry.part_name ??
                ""
            ).trim();

            const unit = String(
                entry.unit ?? ""
            ).trim();

            const month = Number(entry.month);

            const qty =
                entry.qty === null ||
                    entry.qty === undefined ||
                    entry.qty === ""
                    ? null
                    : Number(entry.qty);

            const sellRate =
                entry.sellRate === null ||
                    entry.sellRate === undefined ||
                    entry.sellRate === ""
                    ? null
                    : Number(entry.sellRate);

            /*
             * FINANCIAL YEAR
             *
             * First take Financial Year from Excel row.
             * If missing, use the old frontend dropdown value
             * as fallback.
             */
            const rowFinancialYear =
                entry.financialYear !== undefined &&
                    entry.financialYear !== null &&
                    String(entry.financialYear).trim() !== ""
                    ? String(entry.financialYear).trim()
                    : fallbackFinancialYear;

            /* -----------------------------------------
               FINANCIAL YEAR
            ----------------------------------------- */

            if (!rowFinancialYear) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message: "Financial Year is required",
                });

                return;
            }

            /*
             * Optional format validation.
             *
             * Expected:
             * 2026-27
             * 2027-28
             */
            if (!/^\d{4}-\d{2}$/.test(rowFinancialYear)) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        `Invalid Financial Year '${rowFinancialYear}'. Expected format YYYY-YY.`,
                });

                return;
            }

            /* -----------------------------------------
               PART NO.
            ----------------------------------------- */

            if (!partNo) {
                errors.push({
                    row: excelRow,
                    message: "Part No. is required",
                });

                return;
            }

            const part = partMap.get(
                partNo.toLowerCase()
            );

            if (!part) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        `Part No. '${partNo}' was not found in Part Master`,
                });

                return;
            }

            /* -----------------------------------------
               PART NAME
            ----------------------------------------- */

            if (!partName) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message: "Part Name is required",
                });

                return;
            }

            /*
             * Part Master remains the authoritative
             * source for saved Part Name.
             */
            const finalPartName =
                part.part_name ||
                partName ||
                null;

            /* -----------------------------------------
               UNIT
            ----------------------------------------- */

            if (!unit) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message: "Unit is required",
                });

                return;
            }

            const unitMaster = unitMap.get(
                unit.toLowerCase()
            );

            if (!unitMaster) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        `Unit '${unit}' was not found in Unit Master`,
                });

                return;
            }

            /* -----------------------------------------
               MONTH
            ----------------------------------------- */

            if (
                !Number.isInteger(month) ||
                month < 1 ||
                month > 12
            ) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        "Month must be between 1 and 12",
                });

                return;
            }

            /* -----------------------------------------
               QTY
            ----------------------------------------- */

            if (
                qty !== null &&
                (
                    !Number.isFinite(qty) ||
                    qty < 0
                )
            ) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        "Qty must be a valid non-negative number",
                });

                return;
            }

            /* -----------------------------------------
               SELLS RATE
            ----------------------------------------- */

            if (
                sellRate !== null &&
                (
                    !Number.isFinite(sellRate) ||
                    sellRate < 0
                )
            ) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        "Sells Rate must be a valid non-negative number",
                });

                return;
            }

            /* -----------------------------------------
               VALUE REQUIRED
            ----------------------------------------- */

            if (
                qty === null &&
                sellRate === null
            ) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        "Qty or Sells Rate is required",
                });

                return;
            }

            /* -----------------------------------------
               DUPLICATE INSIDE EXCEL
            ----------------------------------------- */

            const duplicateKey =
                `${part.id}||${unitMaster.id}||${month}||${rowFinancialYear}||${sellRate}`;

            if (duplicateMap.has(duplicateKey)) {
                errors.push({
                    row: excelRow,
                    partNo,
                    message:
                        "Duplicate Part + Unit + Month + Financial Year + Sells Rate found in upload",
                });

                return;
            }

            duplicateMap.set(
                duplicateKey,
                true
            );

            /* -----------------------------------------
               VALID RECORD
            ----------------------------------------- */

            validatedEntries.push({
                partId: part.id,

                partNo: part.part_no,

                partName: finalPartName,

                unitId: unitMaster.id,

                unit: unitMaster.unit,

                financialYear: rowFinancialYear,

                month,

                qty,

                sellRate,
            });
        });

        /* -------------------------------------------------
           DO NOT SAVE IF ANY VALIDATION ERROR EXISTS
        ------------------------------------------------- */

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message:
                    "Bulk upload contains invalid records.",
                errors,
                totalErrors: errors.length,
            });
        }

        /* -------------------------------------------------
           DATABASE TRANSACTION
        ------------------------------------------------- */

        connection =
            await zbcDB.getConnection();

        await connection.beginTransaction();

        /* -------------------------------------------------
           INSERT / UPDATE
        ------------------------------------------------- */

        for (const entry of validatedEntries) {
            await connection.query(
                `
                INSERT INTO sales_monthly (
                    part_id,
                    part_no,
                    part_name,
                    unit_id,
                    unit,
                    financial_year,
                    month,
                    qty,
                    sell_rate,
                    created_by,
                    updated_by
                )VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                `,
                [
                    entry.partId,
                    entry.partNo,
                    entry.partName,
                    entry.unitId,
                    entry.unit,
                    entry.financialYear,
                    entry.month,
                    entry.qty,
                    entry.sellRate,
                    userName,
                    userName,
                ]
            );
        }

        /* -------------------------------------------------
           COMMIT
        ------------------------------------------------- */

        await connection.commit();

        return res.status(201).json({
            success: true,
            message:
                `${validatedEntries.length} Sales Monthly records saved successfully.`,
            totalRecords:
                validatedEntries.length,
        });

    } catch (error) {

        /* -------------------------------------------------
           ROLLBACK
        ------------------------------------------------- */

        if (connection) {
            try {
                await connection.rollback();
            } catch (rollbackError) {
                console.error(
                    "Sales Monthly rollback error:",
                    rollbackError
                );
            }
        }

        console.error(
            "Bulk Sales Monthly error:",
            error
        );

        return res.status(500).json({
            success: false,
            message:
                "Failed to save bulk Sales Monthly entries",
            error: error.message,
            code: error.code,
            sqlState: error.sqlState,
        });

    } finally {

        if (connection) {
            connection.release();
        }
    }
};

/* UPDATE SALES MONTHLY */
export const updateSalesMonthly = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const { id } = req.params;
        const {
            partNo,
            partName,
            unit,
            financialYear,
            month,
            qty,
            sellRate,
        } = req.body;
        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Record ID is required",
            });
        }
        if (!partNo || !String(partNo).trim()) {
            return res.status(400).json({
                success: false,
                message: "Part No. is required",
            });
        }
        if (!unit || !String(unit).trim()) {
            return res.status(400).json({
                success: false,
                message: "Unit is required",
            });
        }
        if (!financialYear || !String(financialYear).trim()) {
            return res.status(400).json({
                success: false,
                message: "Financial Year is required",
            });
        }
        const monthNumber = Number(month);
        if (!Number.isInteger(monthNumber) || monthNumber < 1 || monthNumber > 12) {
            return res.status(400).json({
                success: false,
                message: "Invalid Month",
            });
        }
        let finalQty = null;
        if (qty !== undefined && qty !== null && qty !== "") {
            finalQty = Number(qty);
            if (!Number.isFinite(finalQty) || finalQty < 0) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid Qty",
                });
            }
        }
        let finalSellRate = null;
        if (sellRate !== undefined && sellRate !== null && sellRate !== "") {
            finalSellRate = Number(sellRate);
            if (!Number.isFinite(finalSellRate) || finalSellRate < 0) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid Sell Rate",
                });
            }
        }
        if (finalQty === null && finalSellRate === null) {
            return res.status(400).json({
                success: false,
                message: "Enter Qty or Sell Rate",
            });
        }

        /* CHECK PART */
        const [partRows] = await adminDB.query(`
            SELECT id, part_no, part_name
            FROM part_master
            WHERE LOWER(TRIM(part_no))
                    = LOWER(TRIM(?))
            LIMIT 1 `,
            [String(partNo).trim(),]
        );
        if (partRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: `Part No. '${partNo}' was not found in Part Master`,
            });
        }
        const part = partRows[0];

        /* CHECK UNIT */
        const [unitRows] = await adminDB.query(`
            SELECT id, unit
            FROM unit_master
            WHERE LOWER(TRIM(unit))
                    = LOWER(TRIM(?))
            LIMIT 1`,
            [String(unit).trim(),]
        );
        if (unitRows.length === 0) {
            return res.status(404).json({
                success: false,
                message: `Unit '${unit}' was not found in Unit Master`,
            });
        }
        const unitMaster = unitRows[0];

        /* UPDATE */
        const [result] = await zbcDB.query(`
            UPDATE sales_monthly
            SET
                part_id = ?,
                part_no = ?,
                part_name = ?,
                unit_id = ?,
                unit = ?,
                financial_year = ?,
                month = ?,
                qty = ?,
                sell_rate = ?,
                updated_by = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?`,
            [
                part.id,
                part.part_no,
                partName || part.part_name || null,
                unitMaster.id,
                unitMaster.unit,
                String(financialYear).trim(),
                monthNumber,
                finalQty,
                finalSellRate,
                userName,
                id,
            ]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Sales Monthly record not found",
            });
        }

        /* RETURN UPDATED RECORD */
        const [rows] = await zbcDB.query(`
            SELECT
                id,
                part_id,
                part_no,
                part_name,
                unit_id,
                unit,
                financial_year,
                month,
                qty,
                sell_rate,
                created_at,
                updated_at
            FROM sales_monthly
            WHERE id = ?
            LIMIT 1 `,
            [id]
        );
        return res.json({
            success: true,
            message: "Sales Monthly entry updated successfully",
            data: rows[0] || null,
        });

    } catch (error) {
        console.error("Error updating Sales Monthly entry:", error);
        /* Duplicate unique key */
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "A Sales Monthly record already exists for this Part, Month and Financial Year.",
            });
        }
        return res.status(500).json({
            success: false,
            message: "Failed to update Sales Monthly entry",
            error: error.message,
        });
    }
};

/* DELETE SALES MONTHLY */
export const deleteSalesMonthly = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }

        const { id } = req.params;
        if (!id) {
            return res.status(400).json({
                success: false,
                message: "Record ID is required",
            });
        }
        const [result] = await zbcDB.query(`
            DELETE FROM sales_monthly
            WHERE id = ?`,
            [id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: "Sales Monthly record not found",
            });
        }
        return res.json({
            success: true,
            message: "Sales Monthly entry deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting Sales Monthly entry:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to delete Sales Monthly entry",
            error: error.message,
        });
    }
};

//Get Compound Monthly Report
export const getCompoundMonthlyReport = async (req, res) => {
    try {
        const { financial_year } = req.query;
        const [rows] = await zbcDB.query(`
      SELECT
        compound_id,
        compound_code,
        polymer_name,
        im_code,
        unit_id,
        financial_year,
        month,
        qty,
        rate
      FROM compound_monthly_report
      WHERE financial_year = ?
      ORDER BY compound_code, month`,
            [financial_year]
        );
        res.json({ success: true, data: rows, });
    } catch (error) {
        console.error("Error fetching compound monthly report:", error);
        res.status(500).json({
            success: false,
            message: "Failed to fetch compound monthly report",
            error: error.message,
        });
    }
};

//Create Compound Monthly Rate
export const createCompoundMonthlyRate = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const {
            compoundId,
            compoundCode,
            polymer,
            imCode,
            unitId,
            financial_year,
            month,
            qty,
            rate,
        } = req.body;
        if (!compoundId || !unitId || !financial_year || !month) {
            return res.status(400).json({
                success: false,
                message: "Compound, unit, financial_year and month are required",
            });
        }

        await zbcDB.query(`
      INSERT INTO compound_monthly_report (
        compound_id,
        compound_code,
        polymer_name,
        im_code,
        unit_id,
        financial_year,
        month,
        qty,
        rate,
        created_by,
        updated_by
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        compound_code = VALUES(compound_code),
        polymer_name = VALUES(polymer_name),
        im_code = VALUES(im_code),
        qty = VALUES(qty),
        rate = VALUES(rate),
        updated_by = VALUES(updated_by),
        updated_at = CURRENT_TIMESTAMP
    `, [
            compoundId,
            compoundCode,
            polymer,
            imCode,
            unitId,
            financial_year,
            month,
            qty || 0,
            rate || 0,
            userName,
            userName,
        ]);

        res.status(201).json({
            success: true,
            message: "Compound monthly rate saved successfully",
        });
    } catch (error) {
        console.error(
            "Error saving compound monthly rate:", error
        );
        res.status(500).json({
            success: false,
            message: "Failed to save compound monthly rate",
            error: error.message,
        });
    }
};

//Get Compound Rate For Costing
export const getCompoundRateForCosting = async (req, res) => {
    try {
        const {
            compoundCode,
            polymerName,
            imCode,
            unitId,
            financial_year,
            month,
        } = req.query;
        if (
            !compoundCode ||
            !polymerName ||
            !imCode ||
            !unitId ||
            !financial_year ||
            !month
        ) {
            return res.status(400).json({
                success: false,
                message: "Compound Code, Polymer, IM Code, Production Unit, Year and Month are required",
            });
        }
        const [rows] = await zbcDB.query(`
      SELECT
        id,
        compound_id,
        compound_code,
        polymer_name,
        im_code,
        unit_id,
        financial_year,
        month,
        qty,
        rate
      FROM compound_monthly_report
      WHERE compound_code = ?
        AND polymer_name = ?
        AND im_code = ?
        AND unit_id = ?
        AND financial_year = ?
        AND month = ?
      LIMIT 1`,
            [
                compoundCode,
                polymerName,
                imCode,
                Number(unitId),
                String(financial_year),
                Number(month),
            ]
        );
        if (rows.length === 0) {
            return res.json({
                success: true,
                found: false,
                rate: null,
                data: null,
            });
        }
        res.json({
            success: true,
            found: true,
            rate: Number(rows[0].rate) || 0,
            data: rows[0],
        });
    } catch (error) {
        console.error(
            "Error fetching compound costing rate:",
            error
        );
        res.status(500).json({
            success: false,
            message: "Failed to fetch compound rate",
            error: error.message,
        });
    }
};

// Create Bulk Compound Monthly Rate
export const createBulkCompoundMonthlyRate = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const { rows } = req.body;

        /* BASIC REQUEST VALIDATION */
        if (!Array.isArray(rows) || rows.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No Excel records received",
            });
        }
        if (rows.length > 5000) {
            return res.status(400).json({
                success: false,
                message: "Maximum 5000 records can be uploaded at once.",
            });
        }

        const errors = [];
        const validRows = [];

        /* STEP 1: BASIC VALIDATION */
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const excelRow = Number(row.rowNumber) || i + 2;
            const rowErrors = [];
            const imCode = String(row.imCode ?? "").trim();
            const productionUnit = String(row.productionUnit ?? "").trim();
            const financialYear = String(row.financial_year ?? "").trim();
            const month =
                row.month === undefined ||
                    row.month === null ||
                    row.month === ""
                    ? NaN
                    : Number(row.month);
            const qty =
                row.qty === undefined ||
                    row.qty === null ||
                    row.qty === ""
                    ? null
                    : Number(row.qty);
            const rate =
                row.rate === undefined ||
                    row.rate === null ||
                    row.rate === ""
                    ? null
                    : Number(row.rate);

            /* IM CODE */
            if (!imCode) {
                rowErrors.push(
                    "IM Code is required."
                );
            }

            /* PRODUCTION UNIT */
            if (!productionUnit) {
                rowErrors.push(
                    "Production Unit is required."
                );
            }

            /* FINANCIAL YEAR */
            if (!financialYear) {
                rowErrors.push(
                    "Financial Year is required."
                );
            } else if (
                !/^\d{4}-\d{2}$/.test(financialYear)
            ) {
                rowErrors.push(
                    `Invalid Financial Year '${financialYear}'. Expected format YYYY-YY.`
                );
            }

            /* MONTH */
            if (
                !Number.isInteger(month) ||
                month < 1 ||
                month > 12
            ) {
                rowErrors.push(
                    "Month must be between 1 and 12."
                );
            }

            /* QTY */
            if (
                qty === null ||
                !Number.isFinite(qty) ||
                qty < 0
            ) {
                rowErrors.push(
                    "Qty must be a valid non-negative number."
                );
            }

            /* RATE */
            if (
                rate === null ||
                !Number.isFinite(rate) ||
                rate < 0
            ) {
                rowErrors.push(
                    "Rate must be a valid non-negative number."
                );
            }

            /* BASIC VALIDATION FAILED */
            if (rowErrors.length > 0) {
                errors.push({
                    rowNumber: excelRow,
                    imCode,
                    productionUnit,
                    financial_year: financialYear,
                    month: Number.isFinite(month)
                        ? month
                        : row.month ?? "",
                    qty: row.qty ?? "",
                    rate: row.rate ?? "",
                    errors: rowErrors,
                });
                continue;
            }
            validRows.push({
                ...row,
                rowNumber: excelRow,
                imCode,
                productionUnit,
                financial_year: financialYear,
                month,
                qty,
                rate,
            });
        }

        /* STEP 2: GET UNIQUE MASTER VALUES */
        const imCodes = [
            ...new Set(validRows
                .map((row) => String(row.imCode).trim().toLowerCase())
                .filter(Boolean)
            ),
        ];

        const productionUnits = [
            ...new Set(validRows
                .map((row) => String(row.productionUnit).trim().toLowerCase())
                .filter(Boolean)
            ),
        ];

        /* STEP 3: LOAD COMPOUND MASTER */
        let compoundMap = new Map();
        if (imCodes.length > 0) {
            const placeholders = imCodes
                .map(() => "?")
                .join(",");
            const [compoundRows] = await adminDB.query(`
          SELECT id,polymer,compound_code,im_code
          FROM compound_master
          WHERE LOWER(TRIM(im_code))
            IN (${placeholders})`,
                imCodes
            );
            compoundMap = new Map(
                compoundRows.map((compound) => [
                    String(compound.im_code)
                        .trim()
                        .toLowerCase(),
                    compound,
                ])
            );
        }

        /* STEP 4: LOAD UNIT MASTER */
        let unitMap = new Map();
        if (productionUnits.length > 0) {
            const placeholders = productionUnits
                .map(() => "?")
                .join(",");
            const [unitRows] = await adminDB.query(`
          SELECT id,unit
          FROM unit_master
          WHERE LOWER(TRIM(unit))
            IN (${placeholders})`,
                productionUnits
            );

            unitMap = new Map(
                unitRows.map((unit) => [
                    String(unit.unit)
                        .trim()
                        .toLowerCase(),
                    unit,
                ])
            );
        }

        /* STEP 5: MASTER VALIDATION + DUPLICATE VALIDATION */
        const rowsReadyForInsert = [];
        const duplicateMap = new Map();
        for (const row of validRows) {
            const excelRow = row.rowNumber;
            const imCode = String(
                row.imCode
            ).trim();
            const productionUnit = String(
                row.productionUnit
            ).trim();
            const financialYear = String(
                row.financial_year
            ).trim();
            const month = Number(row.month);
            const compound =
                compoundMap.get(
                    imCode.toLowerCase()
                );
            const unit =
                unitMap.get(
                    productionUnit.toLowerCase()
                );
            const rowErrors = [];

            /* COMPOUND MASTER */
            if (!compound) {
                rowErrors.push(
                    `IM Code '${imCode}' not found in Compound Master.`
                );
            }

            /* UNIT MASTER */
            if (!unit) {
                rowErrors.push(
                    `Production Unit '${productionUnit}' not found in Unit Master.`
                );
            }

            /* DUPLICATE */
            if (compound && unit) {
                const duplicateKey =
                    `${compound.id}||${unit.id}||${financialYear}||${month}`;
                if (duplicateMap.has(duplicateKey)) {
                    rowErrors.push(
                        "Duplicate IM Code + Production Unit + Financial Year + Month found in upload."
                    );
                } else {
                    duplicateMap.set(
                        duplicateKey,
                        true
                    );
                }
            }

            /* STORE ERRORS */
            if (rowErrors.length > 0) {
                errors.push({
                    rowNumber: excelRow,
                    imCode,
                    productionUnit,
                    financial_year: financialYear,
                    month,
                    qty: row.qty,
                    rate: row.rate,
                    errors: rowErrors,
                });
                continue;
            }

            /* COMPLETELY VALID ROW */
            rowsReadyForInsert.push({
                ...row,
                compound,
                unit,
            });
        }

        /* STEP 6: DO NOT SAVE ANYTHING IF ANY ROW IS INVALID */
        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Bulk upload contains invalid records.",
                totalRows: rows.length,
                validRows: rowsReadyForInsert.length,
                invalidRows: errors.length,
                errors,
                totalErrors: errors.length,
            });
        }

        /* STEP 7: INSERT ONLY IF ALL ROWS ARE VALID */
        let insertedCount = 0;
        for (const row of rowsReadyForInsert) {
            const compound = row.compound;
            const unit = row.unit;
            await zbcDB.query(`
        INSERT INTO compound_monthly_report (
          compound_id, compound_code, polymer_name, im_code,
          unit_id, financial_year, month, qty, rate,
          created_by, updated_by
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          compound_code = VALUES(compound_code),
          polymer_name = VALUES(polymer_name),
          im_code = VALUES(im_code),
          qty = VALUES(qty),
          rate = VALUES(rate),
          updated_by = VALUES(updated_by),
          updated_at = CURRENT_TIMESTAMP`,
                [
                    compound.id,
                    compound.compound_code || null,
                    compound.polymer || null,
                    compound.im_code || null,
                    unit.id,
                    String(row.financial_year).trim(),
                    Number(row.month),
                    Number(row.qty),
                    Number(row.rate),
                    userName,
                    userName,
                ]
            );
            insertedCount++;
        }

        /* STEP 8: SUCCESS */
        return res.status(201).json({
            success: true,
            message: "Compound monthly rates uploaded successfully.",
            totalRows: rows.length,
            validRows: rowsReadyForInsert.length,
            invalidRows: 0,
            insertedCount,
            errorCount: 0,
            errors: [],
        });

    } catch (error) {
        console.error(
            "Bulk compound upload error:",
            error
        );

        return res.status(500).json({
            success: false,
            message: "Failed to upload compound monthly rates.",
            error: error.message,
            code: error.code,
            sqlState: error.sqlState,
        });
    }
};

// HISTORICAL COMPOUND RATE
export const getHistoricalCompoundRate = async (req, res) => {
    try {
        const { compoundCode, polymerName, imCode, unitId, financial_year, month } = req.query;

        if (!compoundCode || !polymerName || !imCode || !unitId || !financial_year || !month) {
            return res.status(400).json({
                success: false,
                found: false,
                message: "Compound Code, Polymer, IM Code, Production Unit, Year and Month are required",
            });
        }

        // Resolve production unit
        let resolvedUnitId = null;
        if (Number.isInteger(Number(unitId)) && Number(unitId) > 0) {
            resolvedUnitId = Number(unitId);
        } else {
            const [unitRows] = await adminDB.query(`
        SELECT id
        FROM unit_master
        WHERE LOWER(TRIM(unit)) = LOWER(TRIM(?))
        LIMIT 1`,
                [String(unitId).trim()]
            );
            if (unitRows.length > 0) {
                resolvedUnitId = Number(unitRows[0].id);
            }
        }

        if (!resolvedUnitId) {
            return res.json({
                success: true,
                found: false,
                rate: null,
                data: null,
            });
        }

        // Get historical compound rate
        const [rows] = await zbcDB.query(`
      SELECT
        id,
        compound_id,
        compound_code,
        polymer_name,
        im_code,
        unit_id,
        financial_year,
        month,
        qty,
        rate
      FROM compound_monthly_report
      WHERE LOWER(TRIM(compound_code))
            = LOWER(TRIM(?))
        AND LOWER(TRIM(polymer_name))
            = LOWER(TRIM(?))
        AND LOWER(TRIM(im_code))
            = LOWER(TRIM(?))
        AND unit_id = ?
        AND TRIM(financial_year) = TRIM(?)
        AND month = ?
      ORDER BY id ASC
      LIMIT 1`,
            [
                String(compoundCode).trim(),
                String(polymerName).trim(),
                String(imCode).trim(),
                resolvedUnitId,
                String(financial_year).trim(),
                Number(month),
            ]
        );

        if (rows.length === 0) {
            return res.json({
                success: true,
                found: false,
                rate: null,
                data: null,
            });
        }

        return res.json({
            success: true,
            found: true,
            rate: Number(rows[0].rate) || 0,
            data: rows[0],
        });
    } catch (error) {
        console.error(
            "Historical compound rate error:",
            error
        );

        return res.status(500).json({
            success: false,
            found: false,
            message: "Failed to fetch historical compound rate",
            error: error.message,
            code: error.code,
            sqlState: error.sqlState,
        });
    }
};

//Get Bop Monthly Report
export const getBopMonthlyReport = async (req, res) => {
    try {
        const { financial_year } = req.query;
        if (!financial_year) {
            return res.status(400).json({
                success: false,
                message: "Year is required",
            });
        }

        // Get monthly BOP data
        const [rows] = await zbcDB.query(`
      SELECT
        bop_id,
        part_no,
        fg_code,
        bop_part_name,
        bop_part_no,
        bop_erp_code,
        supplier_id,
        financial_year,
        month,
        qty,
        rate
      FROM bop_monthly_report
      WHERE financial_year = ?
      ORDER BY bop_erp_code, supplier_id, month`,
            [financial_year]
        );

        // Get supplier IDs used in this report
        const supplierIds = [
            ...new Set(rows
                .map((row) => Number(row.supplier_id))
                .filter((id) => id > 0)
            ),
        ];
        let supplierMap = new Map();
        if (supplierIds.length > 0) {
            const placeholders = supplierIds
                .map(() => "?")
                .join(",");
            const [supplierRows] = await adminDB.query(`
        SELECT id,  supplier_name
        FROM supplier_master
        WHERE id IN (${placeholders})`,
                supplierIds
            );
            supplierMap = new Map(
                supplierRows.map((supplier) => [
                    String(supplier.id),
                    supplier.supplier_name,
                ])
            );
        }

        // Add supplier name to each monthly row
        const result = rows.map((row) => ({
            ...row, supplier_name: supplierMap.get(String(row.supplier_id)) || "-",
        }));
        res.json({ success: true, data: result, });
    } catch (error) {
        console.error(
            "Error fetching BOP monthly report:", error
        );
        res.status(500).json({
            success: false,
            message: "Failed to fetch BOP monthly report",
            error: error.message,
        });
    }
};

//Create Bop Monthly Rate
export const createBopMonthlyRate = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const {
            bopId,
            partNo,
            fgCode,
            bopPartName,
            bopPartNo,
            bopErpCode,
            supplierId,
            financial_year,
            month,
            qty,
            rate,
        } = req.body;
        if (!bopId) {
            return res.status(400).json({
                success: false,
                message: "BOP is required",
            });
        }
        if (!supplierId || Number(supplierId) <= 0) {
            return res.status(400).json({
                success: false,
                message: "Supplier is required",
            });
        }
        if (!financial_year) {
            return res.status(400).json({
                success: false,
                message: "Year is required",
            });
        }
        if (!month) {
            return res.status(400).json({
                success: false,
                message: "Month is required",
            });
        }
        await zbcDB.query(`
      INSERT INTO bop_monthly_report (
        bop_id,
        part_no,
        fg_code,
        bop_part_name,
        bop_part_no,
        bop_erp_code,
        supplier_id,
        financial_year,
        month,
        qty,
        rate,
        created_by,
        updated_by
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        part_no = VALUES(part_no),
        fg_code = VALUES(fg_code),
        bop_part_name = VALUES(bop_part_name),
        bop_part_no = VALUES(bop_part_no),
        bop_erp_code = VALUES(bop_erp_code),
        qty = VALUES(qty),
        rate = VALUES(rate),
        updated_by = VALUES(updated_by),
        updated_at = CURRENT_TIMESTAMP
    `, [
            bopId,
            partNo || null,
            fgCode || null,
            bopPartName || null,
            bopPartNo || null,
            bopErpCode || null,
            Number(supplierId),
            financial_year,
            Number(month),
            qty || 0,
            rate || 0,
            userName,
            userName,
        ]);

        res.status(201).json({
            success: true,
            message: "BOP monthly rate saved successfully",
        });
    } catch (error) {
        console.error(
            "Error saving BOP monthly rate:",
            error
        );
        res.status(500).json({
            success: false,
            message: "Failed to save BOP monthly rate",
            error: error.message,
        });
    }
};

//Get Bop Rate For Costing
export const getBopRateForCosting = async (req, res) => {
    try {
        const {
            bopId,
            bopErpCode,
            supplierId,
            financial_year,
            month,
        } = req.query;
        if (
            !supplierId ||
            !financial_year ||
            !month ||
            (!bopId && !bopErpCode)
        ) {
            return res.status(400).json({
                success: false,
                found: false,
                message: "BOP, Supplier, Financial Year and Month are required",
            });
        }
        const [rows] = await zbcDB.query(`
      SELECT
        id,
        bop_id,
        bop_erp_code,
        supplier_id,
        financial_year,
        month,
        qty,
        rate
      FROM bop_monthly_report
      WHERE
        (bop_id = ?
          OR LOWER(TRIM(bop_erp_code)) =
             LOWER(TRIM(?)))
        AND supplier_id = ?
        AND TRIM(financial_year) = TRIM(?)
        AND month = ?
      LIMIT 1`,
            [
                Number(bopId) || 0,
                String(bopErpCode || "").trim(),
                Number(supplierId),
                String(financial_year || "").trim(),
                Number(month),
            ],
        );
        if (rows.length === 0) {
            return res.json({
                success: true,
                found: false,
                rate: null,
                data: null,
            });
        }

        return res.json({
            success: true,
            found: true,
            rate: Number(rows[0].rate) || 0,
            data: rows[0],
        });

    } catch (error) {
        console.error("BOP RATE ERROR:", error);

        return res.status(500).json({
            success: false,
            found: false,
            message: "Failed to fetch BOP rate",
            error: error.message,
        });
    }
};

// Create Bulk Bop Monthly Rate
export const createBulkBopMonthlyRate = async (req, res) => {
    try {
        const userName = req.user?.user_name;

        if (!userName) {
            return res.status(401).json({
                success: false,
                message: "Authenticated user not found",
            });
        }
        const { rows } = req.body;
        /* BASIC REQUEST VALIDATION */

        if (!Array.isArray(rows) || rows.length === 0) {
            return res.status(400).json({
                success: false,
                message: "No Excel records received",
            });
        }

        if (rows.length > 5000) {
            return res.status(400).json({
                success: false,
                message: "Maximum 5000 records can be uploaded at once.",
            });
        }

        const errors = [];
        const validRows = [];

        /* STEP 1: BASIC VALIDATION FOR ALL EXCEL ROWS */
        for (let i = 0; i < rows.length; i++) {
            const row = rows[i];
            const excelRow = Number(row.rowNumber) || i + 2;
            const rowErrors = [];
            const bopErpCode = String(row.bopErpCode ?? "").trim();
            const supplierName = String(row.supplierName ?? "").trim();
            const financialYear = String(row.financial_year ?? "").trim();
            const month =
                row.month === undefined ||
                    row.month === null ||
                    row.month === ""
                    ? NaN
                    : Number(row.month);
            const qty =
                row.qty === undefined ||
                    row.qty === null ||
                    row.qty === ""
                    ? null
                    : Number(row.qty);
            const rate =
                row.rate === undefined ||
                    row.rate === null ||
                    row.rate === ""
                    ? null
                    : Number(row.rate);

            // BOP ERP Code
            if (!bopErpCode) {
                rowErrors.push("BOP ERP Code is required");
            }

            // Supplier Name
            if (!supplierName) {
                rowErrors.push("Supplier Name is required");
            }

            // Financial Year
            if (!financialYear) {
                rowErrors.push("Financial Year is required");
            } else if (!/^\d{4}-\d{2}$/.test(financialYear)) {
                rowErrors.push(
                    `Invalid Financial Year '${financialYear}'. Expected format YYYY-YY.`
                );
            }

            // Month
            if (!Number.isInteger(month) || month < 1 || month > 12) {
                rowErrors.push("Month must be between 1 and 12");
            }

            // Qty
            if (
                qty === null ||
                !Number.isFinite(qty) ||
                qty < 0
            ) {
                rowErrors.push("Qty must be a valid non-negative number");
            }

            // Rate
            if (
                rate === null ||
                !Number.isFinite(rate) ||
                rate < 0
            ) {
                rowErrors.push("Rate must be a valid non-negative number");
            }

            if (rowErrors.length > 0) {
                errors.push({
                    rowNumber: excelRow,
                    bopErpCode,
                    supplierName,
                    financial_year: financialYear,
                    month: Number.isFinite(month) ? month : row.month ?? "",
                    qty: row.qty ?? "",
                    rate: row.rate ?? "",
                    errors: rowErrors,
                });
                continue;
            }
            validRows.push({
                ...row,
                rowNumber: excelRow,
                bopErpCode,
                supplierName,
                financial_year: financialYear,
                month,
                qty,
                rate,
            });
        }

        /* STEP 2: GET UNIQUE MASTER VALUES */
        const bopErpCodes = [
            ...new Set(
                validRows
                    .map((row) => row.bopErpCode.toLowerCase())
                    .filter(Boolean)
            ),
        ];

        const supplierNames = [
            ...new Set(
                validRows
                    .map((row) => row.supplierName.toLowerCase())
                    .filter(Boolean)
            ),
        ];

        /* STEP 3: LOAD BOP MASTER */
        let bopMap = new Map();
        if (bopErpCodes.length > 0) {
            const placeholders = bopErpCodes.map(() => "?").join(",");
            const [bopRows] = await adminDB.query(`
        SELECT
          p.id,
          p.bop_part_name,
          p.bop_part_no,
          p.supplier_id,
          p.part_id,
          sd.part_no,
          sd.fg_code,
          p.bop_erp_code
        FROM bop_master p
        LEFT JOIN part_master sd
          ON p.part_id = sd.id
        WHERE LOWER(TRIM(p.bop_erp_code))
          IN (${placeholders})`,
                bopErpCodes
            );
            bopMap = new Map(
                bopRows.map((bop) => [String(bop.bop_erp_code).trim().toLowerCase(), bop])
            );
        }

        /* STEP 4: LOAD SUPPLIER MASTER */
        let supplierMap = new Map();
        if (supplierNames.length > 0) {
            const placeholders = supplierNames.map(() => "?").join(",");
            const [supplierRows] = await adminDB.query(`
        SELECT id,supplier_name
        FROM supplier_master
        WHERE LOWER(TRIM(supplier_name))
          IN (${placeholders})`,
                supplierNames
            );

            supplierMap = new Map(
                supplierRows.map((supplier) => [String(supplier.supplier_name).trim().toLowerCase(), supplier])
            );
        }

        /* STEP 5: MASTER VALIDATION */
        const rowsReadyForInsert = [];
        const duplicateMap = new Map();
        for (const row of validRows) {
            const excelRow = row.rowNumber;
            const bopErpCode = row.bopErpCode;
            const supplierName = row.supplierName;
            const bop = bopMap.get(bopErpCode.toLowerCase());
            const supplier = supplierMap.get(supplierName.toLowerCase());
            const rowErrors = [];

            // BOP Master
            if (!bop) {
                rowErrors.push(
                    `BOP ERP Code '${bopErpCode}' not found in BOP master`
                );
            }

            // Supplier Master
            if (!supplier) {
                rowErrors.push(
                    `Supplier '${supplierName}' not found in supplier master`
                );
            }

            // Supplier assigned to BOP
            if (bop && supplier) {
                const bopSupplierIds = String(bop.supplier_id || "")
                    .split(",")
                    .map((id) => id.trim())
                    .filter(Boolean);

                if (!bopSupplierIds.includes(String(supplier.id))) {
                    rowErrors.push(
                        `Supplier '${supplierName}' is not assigned to BOP '${bopErpCode}'`
                    );
                }
            }

            /* DUPLICATE CHECK */
            if (bop && supplier) {
                const duplicateKey = `${bop.id}||${supplier.id}||${row.financial_year}||${row.month}`;
                if (duplicateMap.has(duplicateKey)) {
                    rowErrors.push(
                        "Duplicate BOP + Supplier + Financial Year + Month found in upload"
                    );
                } else {
                    duplicateMap.set(duplicateKey, true);
                }
            }

            if (rowErrors.length > 0) {
                errors.push({
                    rowNumber: excelRow,
                    bopErpCode,
                    supplierName,
                    financial_year: row.financial_year,
                    month: row.month,
                    qty: row.qty,
                    rate: row.rate,
                    errors: rowErrors,
                });
                continue;
            }
            rowsReadyForInsert.push({
                ...row,
                bop,
                supplier,
            });
        }

        /* DO NOT SAVE ANYTHING IF ANY ROW IS INVALID */
        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: "Bulk upload contains invalid records.",
                totalRows: rows.length,
                validRows: rowsReadyForInsert.length,
                invalidRows: errors.length,
                errors,
                totalErrors: errors.length,
            });
        }

        /* STEP 6: INSERT ONLY WHEN ALL ROWS ARE VALID */
        let insertedCount = 0;
        for (const row of rowsReadyForInsert) {
            const bop = row.bop;
            const supplier = row.supplier;
            await zbcDB.query(`
        INSERT INTO bop_monthly_report (
          bop_id,
          part_no,
          fg_code,
          bop_part_name,
          bop_part_no,
          bop_erp_code,
          supplier_id,
          financial_year,
          month,
          qty,
          rate,
          created_by,
          updated_by
        )VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          part_no = VALUES(part_no),
          fg_code = VALUES(fg_code),
          bop_part_name = VALUES(bop_part_name),
          bop_part_no = VALUES(bop_part_no),
          bop_erp_code = VALUES(bop_erp_code),
          qty = VALUES(qty),
          rate = VALUES(rate),
          updated_by = VALUES(updated_by),
          updated_at = CURRENT_TIMESTAMP`,
                [
                    bop.id,
                    bop.part_no || null,
                    bop.fg_code || null,
                    bop.bop_part_name || null,
                    bop.bop_part_no || null,
                    bop.bop_erp_code || null,
                    Number(supplier.id),
                    String(row.financial_year).trim(),
                    Number(row.month),
                    Number(row.qty),
                    Number(row.rate),
                    userName,
                    userName,
                ]
            );
            insertedCount++;
        }

        /* SUCCESS */
        return res.status(201).json({
            success: true,
            message: `${insertedCount} BOP monthly records saved successfully.`,
            totalRows: rows.length,
            insertedCount,
            errorCount: 0,
            errors: [],
        });
    } catch (error) {
        console.error("Bulk BOP upload error:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to upload BOP monthly rates",
            error: error.message,
            code: error.code,
            sqlState: error.sqlState,
        });
    }
};
