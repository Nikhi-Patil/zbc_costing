import express from "express";
import {
  getCompoundPolymerMonthlyReport,
  getCustomerWiseMonthlyReport,
} from "../controllers/monthlyReports.js";
import { authenticateToken } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(authenticateToken);

router.get(
    "/monthly-compound-polymer-report",
    getCompoundPolymerMonthlyReport);

router.get(
    "/customer-wise-report",
    getCustomerWiseMonthlyReport
);

export default router;