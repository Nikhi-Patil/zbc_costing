import express from "express";

import {
    getAllBops,
    getAllCompounds,
    getAllCustomers,
    getAllEmployees,
    getAllParts,
    getAllSubCategories,
    getAllSubDepartments,
    getAllUnits,
    getAllMachines,
    getCompoundByImCode,
    getAllMargins,
} from "../controllers/masterController.js";

import { authenticateToken } from "../middleware/authMiddleware.js";

const router = express.Router();
router.use(authenticateToken);

router.get("/bops", getAllBops);
router.get("/compounds", getAllCompounds);
router.get("/customers", getAllCustomers);
router.get("/employees", getAllEmployees);
router.get("/parts", getAllParts);
router.get("/subcategories", getAllSubCategories);
router.get("/subdepartments", getAllSubDepartments);
router.get("/units", getAllUnits);
router.get("/machines", getAllMachines);
router.get("/margins", getAllMargins);
router.get("/compound-by-im-code", getCompoundByImCode);
export default router;