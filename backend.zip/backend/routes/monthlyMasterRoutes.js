import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";

import {
  getSalesMonthlyReport,
  getPreviousMonthSales,
  getSalesMonthlyById,
  checkSalesMonthly,
  createSalesMonthly,
  bulkCreateSalesMonthly,
  updateSalesMonthly,
  deleteSalesMonthly,
  getCompoundMonthlyReport,
  createCompoundMonthlyRate,
  getBopMonthlyReport,
  createBopMonthlyRate,
  getCompoundRateForCosting,
  getBopRateForCosting,
  createBulkBopMonthlyRate,
  createBulkCompoundMonthlyRate,
  getHistoricalCompoundRate,
} from "../controllers/monthlyMasterController.js";

const router = express.Router();
router.use(authenticateToken);

/* GET MONTHLY REPORT */
router.get("/", getSalesMonthlyReport);

/* CHECK EXISTING RECORD */
router.get("/check", checkSalesMonthly);

router.get("/previous", getPreviousMonthSales);

/* GET ONE RECORD */


/* CREATE */
router.post("/", authenticateToken, createSalesMonthly);

router.post("/bulk", authenticateToken, bulkCreateSalesMonthly);

/* UPDATE */
router.put("/:id", authenticateToken, updateSalesMonthly);

/* DELETE */
router.delete("/:id", authenticateToken, deleteSalesMonthly);


router.get("/monthly-compound-rate", getCompoundMonthlyReport);
router.post(
  "/monthly-compound-rate",
  authenticateToken,
  createCompoundMonthlyRate
);
router.get("/monthly-bop-rate", getBopMonthlyReport);
router.post(
  "/monthly-bop-rate",
  authenticateToken,
  createBopMonthlyRate
);
router.get("/compound-rate-for-costing", getCompoundRateForCosting);
router.get("/bop-rate-for-costing", getBopRateForCosting);

router.post(
  "/monthly-bop-rate/bulk",
  authenticateToken,
  createBulkBopMonthlyRate
);
router.post(
  "/monthly-compound-rate/bulk",
  authenticateToken,
  createBulkCompoundMonthlyRate
);

router.get("/historical-compound-rate", getHistoricalCompoundRate);

router.get("/:id", getSalesMonthlyById);

export default router;