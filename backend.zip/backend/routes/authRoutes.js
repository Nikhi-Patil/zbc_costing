import express from "express";
import {
  verifyEmployee,
  getEmployeeSubDepartments,
  loginUser,
} from "../controllers/authController.js";
import { requirezbcMasters } from "../middleware/zbcMasterAccess.js";

const router = express.Router();

router.post(
  "/verify",
  (req, res, next) => {
    console.log("1. VERIFY ROUTE REACHED");
    next();
  },
  requirezbcMasters(["employee_master", "unit_master"]),
  (req, res, next) => {
    console.log("2. ZBC MASTER CHECK PASSED");
    next();
  },
  verifyEmployee
);

router.post(
  "/employee-sub-departments",
  requirezbcMasters(["employee_master", "sub_department_master"]),
  getEmployeeSubDepartments
);

router.post(
  "/login",
  requirezbcMasters([
    "employee_master",
    "sub_department_master",
    "unit_master",
  ]),
  loginUser
);

export default router;